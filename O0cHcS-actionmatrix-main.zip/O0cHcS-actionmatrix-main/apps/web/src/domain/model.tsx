import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Journal as JournalModel } from './journal/journal.model'

import { Todo as TodoModel } from './todo/todo.model'

import { Goal as GoalModel } from './goal/goal.model'

import { Habit as HabitModel } from './habit/habit.model'

import { Hobby as HobbyModel } from './hobby/hobby.model'

import { Schedule as ScheduleModel } from './schedule/schedule.model'

import { Focusmode as FocusmodeModel } from './focusmode/focusmode.model'

import { Airesponse as AiresponseModel } from './airesponse/airesponse.model'

import { Hostview as HostviewModel } from './hostview/hostview.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Journal extends JournalModel {}

  export class Todo extends TodoModel {}

  export class Goal extends GoalModel {}

  export class Habit extends HabitModel {}

  export class Hobby extends HobbyModel {}

  export class Schedule extends ScheduleModel {}

  export class Focusmode extends FocusmodeModel {}

  export class Airesponse extends AiresponseModel {}

  export class Hostview extends HostviewModel {}
}
