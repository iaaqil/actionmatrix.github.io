import { User } from '../user'

export class Schedule {
  id: string

  date?: string

  time?: string

  activity?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
