import { Journal } from '../journal'

export class Todo {
  id: string

  description?: string

  status?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  journalId: string

  journal?: Journal
}
