import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Todo } from './todo.model'

export class TodoApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Todo>,
  ): Promise<Todo[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/todos${buildOptions}`)
  }

  static findOne(
    todoId: string,
    queryOptions?: ApiHelper.QueryOptions<Todo>,
  ): Promise<Todo> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/todos/${todoId}${buildOptions}`)
  }

  static createOne(values: Partial<Todo>): Promise<Todo> {
    return HttpService.api.post(`/v1/todos`, values)
  }

  static updateOne(todoId: string, values: Partial<Todo>): Promise<Todo> {
    return HttpService.api.patch(`/v1/todos/${todoId}`, values)
  }

  static deleteOne(todoId: string): Promise<void> {
    return HttpService.api.delete(`/v1/todos/${todoId}`)
  }

  static findManyByJournalId(
    journalId: string,
    queryOptions?: ApiHelper.QueryOptions<Todo>,
  ): Promise<Todo[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/journals/journal/${journalId}/todos${buildOptions}`,
    )
  }

  static createOneByJournalId(
    journalId: string,
    values: Partial<Todo>,
  ): Promise<Todo> {
    return HttpService.api.post(
      `/v1/journals/journal/${journalId}/todos`,
      values,
    )
  }
}
