import { User } from '../user'

export class Habit {
  id: string

  description?: string

  frequency?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
