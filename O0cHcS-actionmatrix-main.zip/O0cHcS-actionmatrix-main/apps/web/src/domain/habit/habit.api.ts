import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Habit } from './habit.model'

export class HabitApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Habit>,
  ): Promise<Habit[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/habits${buildOptions}`)
  }

  static findOne(
    habitId: string,
    queryOptions?: ApiHelper.QueryOptions<Habit>,
  ): Promise<Habit> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/habits/${habitId}${buildOptions}`)
  }

  static createOne(values: Partial<Habit>): Promise<Habit> {
    return HttpService.api.post(`/v1/habits`, values)
  }

  static updateOne(habitId: string, values: Partial<Habit>): Promise<Habit> {
    return HttpService.api.patch(`/v1/habits/${habitId}`, values)
  }

  static deleteOne(habitId: string): Promise<void> {
    return HttpService.api.delete(`/v1/habits/${habitId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Habit>,
  ): Promise<Habit[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/users/user/${userId}/habits${buildOptions}`)
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Habit>,
  ): Promise<Habit> {
    return HttpService.api.post(`/v1/users/user/${userId}/habits`, values)
  }
}
