import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Journal } from './journal.model'

export class JournalApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Journal>,
  ): Promise<Journal[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/journals${buildOptions}`)
  }

  static findOne(
    journalId: string,
    queryOptions?: ApiHelper.QueryOptions<Journal>,
  ): Promise<Journal> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/journals/${journalId}${buildOptions}`)
  }

  static createOne(values: Partial<Journal>): Promise<Journal> {
    return HttpService.api.post(`/v1/journals`, values)
  }

  static updateOne(
    journalId: string,
    values: Partial<Journal>,
  ): Promise<Journal> {
    return HttpService.api.patch(`/v1/journals/${journalId}`, values)
  }

  static deleteOne(journalId: string): Promise<void> {
    return HttpService.api.delete(`/v1/journals/${journalId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Journal>,
  ): Promise<Journal[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/journals${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Journal>,
  ): Promise<Journal> {
    return HttpService.api.post(`/v1/users/user/${userId}/journals`, values)
  }
}
