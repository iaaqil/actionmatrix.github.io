import { User } from '../user'

import { Todo } from '../todo'

import { Airesponse } from '../airesponse'

export class Journal {
  id: string

  title?: string

  content?: string

  likeDislikeFlag?: boolean

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User

  todos?: Todo[]

  airesponses?: Airesponse[]
}
