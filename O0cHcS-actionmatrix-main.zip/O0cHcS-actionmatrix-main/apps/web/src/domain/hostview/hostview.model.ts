import { User } from '../user'

export class Hostview {
  id: string

  viewType?: string

  viewDate?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
