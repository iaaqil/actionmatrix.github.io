import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Hostview } from './hostview.model'

export class HostviewApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Hostview>,
  ): Promise<Hostview[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hostviews${buildOptions}`)
  }

  static findOne(
    hostviewId: string,
    queryOptions?: ApiHelper.QueryOptions<Hostview>,
  ): Promise<Hostview> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hostviews/${hostviewId}${buildOptions}`)
  }

  static createOne(values: Partial<Hostview>): Promise<Hostview> {
    return HttpService.api.post(`/v1/hostviews`, values)
  }

  static updateOne(
    hostviewId: string,
    values: Partial<Hostview>,
  ): Promise<Hostview> {
    return HttpService.api.patch(`/v1/hostviews/${hostviewId}`, values)
  }

  static deleteOne(hostviewId: string): Promise<void> {
    return HttpService.api.delete(`/v1/hostviews/${hostviewId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Hostview>,
  ): Promise<Hostview[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/hostviews${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Hostview>,
  ): Promise<Hostview> {
    return HttpService.api.post(`/v1/users/user/${userId}/hostviews`, values)
  }
}
