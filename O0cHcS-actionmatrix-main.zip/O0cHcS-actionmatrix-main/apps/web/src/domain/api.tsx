import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { JournalApi } from './journal/journal.api'

import { TodoApi } from './todo/todo.api'

import { GoalApi } from './goal/goal.api'

import { HabitApi } from './habit/habit.api'

import { HobbyApi } from './hobby/hobby.api'

import { ScheduleApi } from './schedule/schedule.api'

import { FocusmodeApi } from './focusmode/focusmode.api'

import { AiresponseApi } from './airesponse/airesponse.api'

import { HostviewApi } from './hostview/hostview.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Journal extends JournalApi {}

  export class Todo extends TodoApi {}

  export class Goal extends GoalApi {}

  export class Habit extends HabitApi {}

  export class Hobby extends HobbyApi {}

  export class Schedule extends ScheduleApi {}

  export class Focusmode extends FocusmodeApi {}

  export class Airesponse extends AiresponseApi {}

  export class Hostview extends HostviewApi {}
}
