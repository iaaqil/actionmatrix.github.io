import { User } from '../user'

export class Hobby {
  id: string

  description?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
