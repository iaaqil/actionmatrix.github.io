import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Hobby } from './hobby.model'

export class HobbyApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Hobby>,
  ): Promise<Hobby[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hobbys${buildOptions}`)
  }

  static findOne(
    hobbyId: string,
    queryOptions?: ApiHelper.QueryOptions<Hobby>,
  ): Promise<Hobby> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hobbys/${hobbyId}${buildOptions}`)
  }

  static createOne(values: Partial<Hobby>): Promise<Hobby> {
    return HttpService.api.post(`/v1/hobbys`, values)
  }

  static updateOne(hobbyId: string, values: Partial<Hobby>): Promise<Hobby> {
    return HttpService.api.patch(`/v1/hobbys/${hobbyId}`, values)
  }

  static deleteOne(hobbyId: string): Promise<void> {
    return HttpService.api.delete(`/v1/hobbys/${hobbyId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Hobby>,
  ): Promise<Hobby[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/users/user/${userId}/hobbys${buildOptions}`)
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Hobby>,
  ): Promise<Hobby> {
    return HttpService.api.post(`/v1/users/user/${userId}/hobbys`, values)
  }
}
