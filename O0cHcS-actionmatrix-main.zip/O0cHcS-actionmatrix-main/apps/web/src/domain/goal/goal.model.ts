import { User } from '../user'

export class Goal {
  id: string

  description?: string

  status?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
