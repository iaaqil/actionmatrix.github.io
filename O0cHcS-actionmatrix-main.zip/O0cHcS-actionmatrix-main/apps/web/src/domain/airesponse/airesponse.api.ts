import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Airesponse } from './airesponse.model'

export class AiresponseApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Airesponse>,
  ): Promise<Airesponse[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/airesponses${buildOptions}`)
  }

  static findOne(
    airesponseId: string,
    queryOptions?: ApiHelper.QueryOptions<Airesponse>,
  ): Promise<Airesponse> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/airesponses/${airesponseId}${buildOptions}`)
  }

  static createOne(values: Partial<Airesponse>): Promise<Airesponse> {
    return HttpService.api.post(`/v1/airesponses`, values)
  }

  static updateOne(
    airesponseId: string,
    values: Partial<Airesponse>,
  ): Promise<Airesponse> {
    return HttpService.api.patch(`/v1/airesponses/${airesponseId}`, values)
  }

  static deleteOne(airesponseId: string): Promise<void> {
    return HttpService.api.delete(`/v1/airesponses/${airesponseId}`)
  }

  static findManyByJournalId(
    journalId: string,
    queryOptions?: ApiHelper.QueryOptions<Airesponse>,
  ): Promise<Airesponse[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/journals/journal/${journalId}/airesponses${buildOptions}`,
    )
  }

  static createOneByJournalId(
    journalId: string,
    values: Partial<Airesponse>,
  ): Promise<Airesponse> {
    return HttpService.api.post(
      `/v1/journals/journal/${journalId}/airesponses`,
      values,
    )
  }
}
