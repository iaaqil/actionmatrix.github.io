import { Journal } from '../journal'

export class Airesponse {
  id: string

  responseText?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  journalId: string

  journal?: Journal
}
