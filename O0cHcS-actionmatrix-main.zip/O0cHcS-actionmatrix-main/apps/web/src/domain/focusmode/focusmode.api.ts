import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Focusmode } from './focusmode.model'

export class FocusmodeApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Focusmode>,
  ): Promise<Focusmode[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/focusmodes${buildOptions}`)
  }

  static findOne(
    focusmodeId: string,
    queryOptions?: ApiHelper.QueryOptions<Focusmode>,
  ): Promise<Focusmode> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/focusmodes/${focusmodeId}${buildOptions}`)
  }

  static createOne(values: Partial<Focusmode>): Promise<Focusmode> {
    return HttpService.api.post(`/v1/focusmodes`, values)
  }

  static updateOne(
    focusmodeId: string,
    values: Partial<Focusmode>,
  ): Promise<Focusmode> {
    return HttpService.api.patch(`/v1/focusmodes/${focusmodeId}`, values)
  }

  static deleteOne(focusmodeId: string): Promise<void> {
    return HttpService.api.delete(`/v1/focusmodes/${focusmodeId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Focusmode>,
  ): Promise<Focusmode[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/focusmodes${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Focusmode>,
  ): Promise<Focusmode> {
    return HttpService.api.post(`/v1/users/user/${userId}/focusmodes`, values)
  }
}
