import { User } from '../user'

export class Focusmode {
  id: string

  startTime?: string

  duration?: string

  lowPowerModeFlag?: boolean

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
