import { Notification } from '../notification'

import { Journal } from '../journal'

import { Goal } from '../goal'

import { Habit } from '../habit'

import { Hobby } from '../hobby'

import { Schedule } from '../schedule'

import { Focusmode } from '../focusmode'

import { Hostview } from '../hostview'

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string
  email?: string
  status: UserStatus
  name?: string
  pictureUrl?: string
  password?: string
  dateCreated: string
  dateUpdated: string
  notifications?: Notification[]

  journals?: Journal[]

  goals?: Goal[]

  habits?: Habit[]

  hobbys?: Hobby[]

  schedules?: Schedule[]

  focusmodes?: Focusmode[]

  hostviews?: Hostview[]
}
